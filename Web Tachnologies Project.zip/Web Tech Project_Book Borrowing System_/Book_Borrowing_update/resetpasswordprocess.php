<?php
      if (session_status() >= 0)
      {
            if(isset($_SESSION["email"])) 
            {
              header("refresh: 0.5; url = PRIVATE.PHP");
            }
      }


if (isset($_POST["reset"]))
{
$email =$_POST["email"] ;
$newpass = $_POST["newpass"];
$confirmpass = $_POST["confirmpass"];

$conn = mysqli_connect('localhost', 'root', '', 'bookborrow');
$sql = "SELECT *FROM logintb WHERE Email = '$email'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$count = mysqli_num_rows($result);

if ($count == 1) 
{
      session_start();
      $_SESSION["email"] = $email;
      $newpass = $_POST["newpass"];
      $confirmpass = $_POST["confirmpass"];

      $conn = mysqli_connect('localhost', 'root', '', 'bookborrow');
      $sql = "UPDATE logintb SET Password = '$newpass', Confirm_Password = '$confirmpass' WHERE Email = '$email'";
      $result = mysqli_query($conn, $sql);
     

      echo "Your Password Change Successfully done";
      header("refresh: 2; url = index.html");
      exit();
}
else{
      echo "User not found";
      header("refresh: 2; url = index.php");
      exit();
}
}
if (!isset($_POST["resat"]))
      {
            echo "Fill the all."."<br>";
            header("refresh: 2; url = index.php");
      }
     
?>