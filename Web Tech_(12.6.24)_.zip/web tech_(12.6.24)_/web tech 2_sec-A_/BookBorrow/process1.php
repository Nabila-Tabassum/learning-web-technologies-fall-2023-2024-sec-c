<!DOCTYPE html>
<html>
<head>
    <title>Book Borrow</title>
</head>
<body>

    <h1 style="text-align:center;">Book Borrowing System</h1>

    <form action="" method="post">
        <label for="sname">Student Name:</label>
        <input type="text" id="sname" name="sname">&nbsp;
        
        <label for="sid">Student ID:</label>
        <input type="text" id="sid" name="sid"><br><br>
        
        <label for="book">Choose a Book:</label>
        <select name="book">
            <option value="book1">book1</option>
            <option value="book2">book2</option>
            <option value="book3">book3</option>
            <option value="book4">book4</option>
            <option value="book5">book5</option>
            <option value="book6">book6</option>
        </select><br><br>
        
        <label for="borrowdate">Borrow Date:</label>
        <input type="date" id="borrowdate" name="borrowdate"><br><br>
        
        <input type="submit" name="submit" value="Submit">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        echo "<h2>Form Data:</h2>";
        echo "Student Name: " . $_POST['sname'] . "<br>";
        echo "Student ID: " . $_POST['sid'] . "<br>";
        echo "Selected Book: " . $_POST['book'] . "<br>";
        echo "Borrow Date: " . $_POST['borrowdate'] . "<br>";
    }
    ?>

</body>
</html>

